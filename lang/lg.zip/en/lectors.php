<?php

return [
    "h1" => "Лектора",
    "webinar_count" => "лекции",
    "filter" => "Направление",
    "min" => "мин",
];
