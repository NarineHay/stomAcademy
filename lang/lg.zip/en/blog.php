<?php

return [
    "category_title" => "Рубрики",
    "more_blogs" => "Еще статьи"
];
